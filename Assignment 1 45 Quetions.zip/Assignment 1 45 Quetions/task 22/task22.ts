var a:string[]=["Pakistan", "Afghanistan", "China", "Iran", "India", "Russia"]
console.log("Naighbouring countries of "+a[1]+" are "+a[2]+" , "+a[3]+" , "+a[4]+" , "+a[5]+" and "+a[6])


console.log("\n\nOOPs array index starts from 0. OKAY lets correct it....")

console.log("\n\nNaighbouring countries of "+a[0]+" are "+a[1]+" , "+a[2]+" , "+a[3]+" , "+a[4]+" and "+a[5])

console.log("Its Good Now...")
