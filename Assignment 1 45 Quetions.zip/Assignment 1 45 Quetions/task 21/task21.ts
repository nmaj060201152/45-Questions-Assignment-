var a:string[]=["Pakistan", "Afghanistan", "China", "Iran", "India", "Russia"]
console.log("Naighbouring countries of "+a[0]+" are "+a[1]+" , "+a[2]+" , "+a[3]+" , "+a[4]+" and "+a[5])

var b:string[]=["Asia", "Africa", "Europe"]
console.log("All of neighbouring countries are contained in continents "+b[0]+" and "+b[2])
console.log("Continent is a good example of object in OOP, it is a generic name, can be used to define an object")