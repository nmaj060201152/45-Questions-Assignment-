var a = "navaid";
console.log("Hello " + a + ", would you like to learn some Python today?");
