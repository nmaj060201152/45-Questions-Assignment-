var a:string = "navaid"; 
console.log("Hello "+a+", would you like to learn some Python today?") 
