var a = "navaid";
console.log("UpperCase Name is ", a.toUpperCase());
console.log("lowercase Name is ", a.toLowerCase());
// console.log("titlecase Name is ",a.toTitleCase()) 
