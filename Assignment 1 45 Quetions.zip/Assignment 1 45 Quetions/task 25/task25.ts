var alien_color = "green"
if (alien_color == "green") {
    console.log("\n\nCongratulation; You! hv earned 5 points..\n")
}

if (alien_color == "red") {
    console.log("\n\nCongratulation; You! hv earned 5 points..\n")
}
