var a:string[] = ["Papa", "Amitabh", "Sir Zia", "Arshad", "Imran Khan"]
console.log(a[0]+", you are invited for a dinner tonight")
console.log("Mr."+a[1]+", you are invited for a dinner tonight")
console.log(a[2]+", you are invited for a dinner tonight")

console.log("\n"+a[0]+", can't come he is no more...\nnow Mr."+a[3]+" you are invited for the same...\n ")
console.log("Mr."+a[1]+", can't come, Visa Problem...\nnow Mr."+a[4]+" you are invited for the same...\n ")

console.log("Fresh List\n")
console.log("Mr."+a[2]+", you are invited for a dinner tonight")
console.log("Mr."+a[3]+", you are invited for a dinner tonight")
console.log("Mr."+a[4]+", you are invited for a dinner tonight")


