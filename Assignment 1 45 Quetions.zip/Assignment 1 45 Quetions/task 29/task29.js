var favFruits = ["Mango", "Orange", "Strawberry"];
if (favFruits.indexOf("Mango") !== -1) {
    console.log("your fav fruit " + favFruits[0] + " is in the list");
}
if (favFruits.indexOf("Apple") !== -1) {
    console.log("apple is in the list of your fav fruits");
}
else {
    console.log("apple is not in the list of your fav fruits");
}
