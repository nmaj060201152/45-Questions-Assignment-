var a = ["sports car", "ship", "helicoptor"];
console.log("\nSameer would like to own a " + a[1] + "\n");
console.log("\nAyan would like to own a " + a[2] + "\n");
console.log("\nRohan would like to own a " + a[0] + "\n");
