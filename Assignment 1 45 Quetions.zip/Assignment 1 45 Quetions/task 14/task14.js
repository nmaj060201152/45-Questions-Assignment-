var a = ["Papa", "Amitabh", "Sir Zia"];
console.log(a[0] + ", you are invited for a dinner tonight");
console.log("Mr." + a[1] + ", you are invited for a dinner tonight");
console.log(a[2] + ", you are invited for a dinner tonight");
