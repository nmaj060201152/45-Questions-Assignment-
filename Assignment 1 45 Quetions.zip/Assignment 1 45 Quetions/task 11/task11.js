var a = ["Junaid", "Obaid", "Zeeshan"];
console.log("One of my best friend's name is " + a[0] + "\n");
console.log("second of my best friend's name is " + a[1] + "\n");
console.log("Third of my best friend's name is " + a[2]);
