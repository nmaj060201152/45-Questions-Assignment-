var alien_color = "green"
if (alien_color == "green") {
    console.log("\n\nCongratulation; You! hv earned 5 points..\n")
}
else{
if (alien_color == "red") {
    console.log("\n\nCongratulation; You! hv earned 15 points..\n")
} 
else{
    if (alien_color == "yellow") {
        console.log("\n\nCongratulation; You! hv earned 10 points..\n")
    }
}}
