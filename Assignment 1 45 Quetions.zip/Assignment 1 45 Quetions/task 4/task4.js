console.log("Navaid Sumalani once said, ", Shadi, na, karna, yaro, Pachtao, gay, sari, life, "");
