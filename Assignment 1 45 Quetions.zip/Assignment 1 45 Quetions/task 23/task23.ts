var houseNo='192', street='5', area='clifton', city = 'karachi', province='sindh', country = 'Pakistan' ;
console.log("Is houseNo == '192'? I predict True.")
console.log(houseNo == '192')

console.log("\n\nIs street == '5'? I predict True.")
console.log(street == '5')

console.log("\n\nIs area == 'clifton'? I predict True.")
console.log(area == 'clifton')

console.log("\n\nIs city == 'karachi'? I predict True.")
console.log(city == 'karachi')

console.log("\n\nIs province == 'sindh'? I predict True.")
console.log(province == 'sindh')

console.log("\n\nIs country == 'Pakistan'? I predict True.")
console.log(country == 'Pakistan')

console.log("\n\nthis was my address, where do shiekh Hasina Wajid live")

console.log("\n\nIs houseNo == '122'? I predict True.")
console.log(houseNo == '122')

console.log("\n\nIs street == '4'? I predict True.")
console.log(street == '4')

console.log("\n\nIs area == 'Defence'? I predict True.")
console.log(area == 'Defence')

console.log("\n\nIs city == 'Quetta'? I predict True.")
console.log(city == 'Quetta')

console.log("\n\nIs province == 'Punjab'? I predict True.")
console.log(province == 'Punjab')

console.log("\n\nIs country == 'India'? I predict True.")
console.log(country == 'India')