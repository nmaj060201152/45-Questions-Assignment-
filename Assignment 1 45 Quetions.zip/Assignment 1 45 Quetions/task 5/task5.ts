var a:string = "Navaid Sumalani"; 
console.log(a+" once said, Shadi na karna yaro, Pachtao gay sari life") 
