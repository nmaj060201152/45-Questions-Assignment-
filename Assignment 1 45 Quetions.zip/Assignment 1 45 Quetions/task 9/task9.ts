var a:number = 6;
console.log("My fav number is "+a+"\n")
console.log("Hum 2, Hamarey "+(a-2))