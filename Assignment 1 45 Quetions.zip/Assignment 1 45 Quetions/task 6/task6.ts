var a:string = "Navaid Sumalani"; 
console.log("Name with white spaces included is\t"+a+"\n")
console.log("Name without white spaces is "+a)