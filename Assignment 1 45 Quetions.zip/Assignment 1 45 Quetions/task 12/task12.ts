var a:string[] = (["Junaid", "Obaid", "Zeeshan"])
console.log("Mr."+a[0]+" please come to my home.\n")
console.log("Mr."+a[1]+" please come to my home.\n")
console.log("Mr."+a[2]+" please come to my home.\n")