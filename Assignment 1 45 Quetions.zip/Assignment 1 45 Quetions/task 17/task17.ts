var a:string[] = ["Danish","Sir Zia", "Imran Khan"]
console.log("Salam, Mr."+a[0]+" Sorry to inform you that due to some reason we cant invite you for dinner, program for you is postponded, next time INSHALLAH, Biryani for u...")
console.log("\nSalam, "+a[1]+" You are still invited...")
console.log("\nSalam, Mr."+a[2]+" You are still invited...")
console.log("Now deleting list")
delete a[0]
delete a[1]
delete a[2]

console.log("Printing Guests list")

console.log(a[0])
console.log(a[0])
console.log(a[0])

console.log("\nSorry list is empty....")
