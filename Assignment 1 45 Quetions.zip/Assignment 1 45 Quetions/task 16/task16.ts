var a:string[] = ["Aamir Khan", "Shazia Baji", "Danish"]
console.log("Big Party is fixed\n")
console.log("Mr."+a[0]+", you are invited for a dinner tonight\n")
console.log("Lovely "+a[1]+", you are invited for a dinner tonight\n")

console.log("Mr."+a[2]+", you are invited for a dinner tonight")


