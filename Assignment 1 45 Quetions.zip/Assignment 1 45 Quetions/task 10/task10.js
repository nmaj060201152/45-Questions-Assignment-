var a = 5;
var b = 9;
console.log("task " + a + " is truth\n");
console.log("task " + b + " is tamanna");
