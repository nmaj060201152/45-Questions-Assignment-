var a:string[]=["Pakistan", "Afghanistan", "China", "Iran", "India"]
console.log("Naighbouring countries of "+a[0]+" are "+a[1]+" , "+a[2]+" , "+a[3]+" and "+a[4])