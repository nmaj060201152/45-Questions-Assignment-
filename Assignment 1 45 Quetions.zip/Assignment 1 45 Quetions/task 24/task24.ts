var smartness="i am smart", intelligence="i am intellegent", myName = "NAVAID", num1=55, num2:number[] = [2,4,6];
console.log("Am I smart? I predict True.")
console.log(smartness == "i am smart")

console.log("\n\nI am not intellegent? I predict True.")
console.log(intelligence =="i am not intellegent")

console.log("\n\nmy name in lowercase is navaid")
console.log(myName.toLowerCase() == 'navaid')

console.log("\n\nmy name in lowercase is Navaid")
console.log(myName.toLowerCase() == 'Navaid')

console.log("\n\n55 is equal to 55")
console.log(num1 == 55)

console.log("\n\n55 is equal to 55")
console.log(num1 !== 55)

console.log("\n\n55 is greater than 50")
console.log(num1 > 50)

console.log("\n\n55 is greater than or equal to 56")
console.log(num1 >= 56)

console.log("\n\n55 is less than 56")
console.log(num1 < 50)

console.log("\n\n55 is less than or equal to 56")
console.log(num1 <= 56)

console.log("\n\n55 is less than or equal to 50")
console.log(num1 >= 50)

console.log("\n\n55 is less than to 56 and greater than 50")
console.log(num1 < 56 && num1 > 50)

console.log("\n\n55 is less than 56 or equal to 55")
console.log(num1 < 56 || num1==55)

console.log("\n\n5 is in num2")
console.log(num2.indexOf(5)==-1)

console.log("\n\n6 is in num2")
console.log(num2.indexOf(6)==-1)

