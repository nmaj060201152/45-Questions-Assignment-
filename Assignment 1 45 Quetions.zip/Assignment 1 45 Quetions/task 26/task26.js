var alien_color = "green";
if (alien_color == "green") {
    console.log("\n\nCongratulation; You! hv earned 5 points for shooting the alien..\n");
}
else {
    console.log("\n\nCongratulation; You! hv earned 10 points..\n");
}
