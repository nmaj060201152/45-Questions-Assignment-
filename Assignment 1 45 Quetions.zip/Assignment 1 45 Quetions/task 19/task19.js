console.log("task 14 again, now to count length of array\n\n");
var a = ["Papa", "Amitabh", "Sir Zia"];
console.log(a[0] + ", you are invited for a dinner tonight");
console.log("Mr." + a[1] + ", you are invited for a dinner tonight");
console.log(a[2] + ", you are invited for a dinner tonight");
var b = a.length;
console.log("Total " + b + " guests are invited...");
